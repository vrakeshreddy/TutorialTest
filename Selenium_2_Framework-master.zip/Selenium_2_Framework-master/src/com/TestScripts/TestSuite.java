/**
 * Framework - Grazitti Automation Selenium Testing
 * Version - 3.0
 * Creation Date - Nov, 2012
 * Author - Grazitti Interactive
 * Copyright � 2012 Grazitti Interactive. All right reserved.
 **/
package com.TestScripts;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses(value = {RegistrationTest.class,WriteAndDownloadTest.class})
public class TestSuite {
	

}
