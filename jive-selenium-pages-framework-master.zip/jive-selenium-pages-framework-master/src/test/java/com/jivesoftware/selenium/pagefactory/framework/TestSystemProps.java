package com.jivesoftware.selenium.pagefactory.framework;

/**
 * Created by charles.capps on 8/21/14.
 */
public class TestSystemProps {
    public static final String WEB_DRIVER_PATH = System.getProperty("tests.webDriverPath");
}
